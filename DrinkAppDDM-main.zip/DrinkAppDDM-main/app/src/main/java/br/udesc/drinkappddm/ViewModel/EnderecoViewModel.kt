package br.udesc.drinkappddm.ViewModel

import androidx.lifecycle.ViewModel

class EnderecoViewModel : ViewModel() {
}