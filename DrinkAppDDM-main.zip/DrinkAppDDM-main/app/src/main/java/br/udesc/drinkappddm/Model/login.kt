package br.udesc.drinkappddm.Model

class login {
}