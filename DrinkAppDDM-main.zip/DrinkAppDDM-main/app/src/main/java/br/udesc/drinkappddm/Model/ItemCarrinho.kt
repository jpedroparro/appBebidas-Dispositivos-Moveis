package br.udesc.drinkappddm.Model

data class ItemCarrinho (
    val produto: Produto,
    var quantidade: Int
)