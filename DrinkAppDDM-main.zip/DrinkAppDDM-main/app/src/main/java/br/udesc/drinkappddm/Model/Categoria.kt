package br.udesc.drinkappddm.Model

import java.io.Serializable

data class Categoria(
    val nome: String
) : Serializable