package br.udesc.drinkappddm.Api

data class PaymentValidationResponse(val message: String)