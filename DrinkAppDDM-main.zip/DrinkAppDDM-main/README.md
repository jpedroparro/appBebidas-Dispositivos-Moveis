# DrinkAppDDM
## Aplicativo de Bebidas - Disciplina DDM (Desenvolvimento para Dispositivos Móveis)

### Para iniciar a API, executar o comando no caminho ...DrinkAppDDM/ApiAPP

    node infex.js
